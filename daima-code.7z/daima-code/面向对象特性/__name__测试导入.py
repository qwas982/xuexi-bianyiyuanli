import __name__模块

print("-"*50)