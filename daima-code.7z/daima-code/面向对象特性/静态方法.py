class 狗(object):
    @staticmethod
    def 跑():
        print("小狗跑...")

#通过 类名.调用静态方法 - 无需创建对象
狗.跑()