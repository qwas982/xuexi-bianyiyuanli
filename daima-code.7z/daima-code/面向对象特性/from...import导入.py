# from 测试模块1 import 狗
# from 测试模块2 import 说你好
#
# 说你好()
# 旺财 = 狗()
# print(旺财)

#from 测试模块1 import 说你好
# from 测试模块2 import 说你好 as 模块2的说你好
# from 测试模块1 import 说你好

#同名函数,后导入会覆盖先导入,
#as改名 ,前面的语句导入完后,再改
# 说你好()
# 模块2的说你好()

#-------------------分割-------------------
#from...import * 导入全部
from 测试模块1 import *
from 测试模块2 import *

print(标题)
说你好()

狗 = 狗()
print(狗)
