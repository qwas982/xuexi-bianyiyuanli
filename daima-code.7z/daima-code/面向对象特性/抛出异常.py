def 输入密码():
    #提示用户输入密码
    密码 = input("请输入密码: ")

    #判断密码长度是否符合需求
    if len(密码) >= 8:
        return 密码

    #若不合需求,抛出异常
    # elif len(密码) < 8:
    #     raise
    print("主动抛出异常")
    #创建异常对象,可用错误信息字符串作为参数
    异 = Exception("密码长度不够")

    #主动抛出异常
    raise 异

#提示用户输入密码
try:
    print(输入密码())
except Exception as 结果:
    print(结果)