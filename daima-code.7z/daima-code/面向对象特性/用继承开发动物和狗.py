#先不使用继承开发试试
# class 动物:
#     def 吃(self):
#         print("吃")
#     def 喝(self):
#         print("喝")
#     def 睡(self):
#         print("睡")
#     def 跑(self):
#         print("跑")
#
# class 狗:
#     def 吃(self):
#         print("吃")
#     def 喝(self):
#         print("喝")
#     def 睡(self):
#         print("睡")
#     def 跑(self):
#         print("跑")
#     def 吠(self):
#         print("吠")
#
# #创建一个对象 狗
# 旺财 = 狗()
# 旺财.吃()
# 旺财.喝()
# 旺财.睡()
# 旺财.跑()
# 旺财.吠()

#用继承开发
class 动物:
    def 吃(self):
        print("吃---")
    def 喝(self):
        print("喝---")
    def 睡(self):
        print("睡---")
    def 跑(self):
        print("跑---")

class 狗(动物):
    #子类拥有父类的所有方法和属性
    
    # def 吃(self):
    #     print("吃")
    # def 喝(self):
    #     print("喝")
    # def 睡(self):
    #     print("睡")
    # def 跑(self):
    #     print("跑")
    def 吠(self):
        print("吠")

#创建一个对象 狗
旺财 = 狗()
旺财.吃()
旺财.喝()
旺财.睡()
旺财.跑()
旺财.吠()
