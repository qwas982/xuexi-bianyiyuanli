class 工具(object):
    #类属性
    计数 = 0

    @classmethod
    def 秀工具计数(cls):
        print("工具对象的数量 %d"% cls.计数)

    def __init__(self,名字):
        self.名字 = 名字
        #使用类属性
        工具.计数 += 1

#创工具对象
工具1 = 工具("锤子")
工具2 = 工具("镰刀")

#调用类方法
工具.秀工具计数()