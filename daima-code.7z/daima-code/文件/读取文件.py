#打开文件
文件 = open("读我",encoding="UTF-8")

#读写文件
文本 = 文件.read()
print(文本)
print(len(文本))

print("%s -分割线- %s"% ("-" *30,"-" *30))

文本 = 文件.read()
print(文本)
print(len(文本))

#关闭文件
文件.close()