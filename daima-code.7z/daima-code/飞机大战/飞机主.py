import pygame
from 飞机精灵 import *

class 飞机游戏(object):
    '''飞机大战主游戏'''

    def __init__(self):
        print("游戏初始化")
        #创建游戏窗口 时钟 调用私有方法 精灵和精灵组的创建
        self.屏幕 = pygame.display.set_mode(SCREEN_RECT.size)
        self.时钟 = pygame.time.Clock()
        self.__创建精灵()
        #设置定时器事件 敌机 1秒
        pygame.time.set_timer(创建敌人事件,1000)
        pygame.time.set_timer(英雄发射事件,500)

    def __创建精灵(self):
        #创建背景精灵和精灵组
        背景1 = 背景()
        背景2 = 背景(True)


        self.背景组 = pygame.sprite.Group(背景1,背景2)
        #创建敌机的精灵组
        self.敌人组 = pygame.sprite.Group()
        #创建英雄的精灵和精灵组
        self.英雄 = 英雄()
        self.英雄组 = pygame.sprite.Group(self.英雄)


    def 开始游戏(self):
        print("游戏开始")
        while True:
            #设置刷新帧率 事件监听 碰撞检测 更新绘制精灵组 更新显示
            self.时钟.tick(每秒帧率)
            self.__事件监听()
            self.__碰撞检测()
            self.__更新精灵()
            pygame.display.update()
            pass
    def __事件监听(self):
        for 事件 in pygame.event.get():
            if 事件.type == pygame.QUIT:
                飞机游戏.__游戏结束()
            elif 事件.type == 创建敌人事件:
                print("敌机出厂")
                #创建并添加到敌机精灵组
                敌人 = 敌机()
                self.敌人组.add(敌人)
            # elif 事件.type == pygame.KEYDOWN and 事件.key == pygame.K_RIGHT:
            #     print("向右移动")
            elif 事件.type == 英雄发射事件:
                self.英雄.发射()


        #使用键盘提供的方法获取键盘按键
        按键 = pygame.key.get_pressed()
        #判断按键的索引值
        if 按键[pygame.K_RIGHT]:
            #print("向右移动")
            self.英雄.speed = 2
        elif 按键[pygame.K_LEFT]:
            self.英雄.speed = -2
        else:
            self.英雄.speed = 0


    def __碰撞检测(self):
        #子弹摧毁敌机
        pygame.sprite.groupcollide(self.英雄.子弹,self.敌人组,True,True)
        #敌机撞毁英雄
        敌对 = pygame.sprite.spritecollide(self.英雄,self.敌人组,True)
        #判断列表是否有内容
        if len(敌对) > 0:
            #让英雄牺牲  结束游戏
            self.英雄.kill()
            飞机游戏.__游戏结束()

    def __更新精灵(self):
        self.背景组.update()
        self.背景组.draw(self.屏幕)
        self.敌人组.update()
        self.敌人组.draw(self.屏幕)
        self.英雄组.update()
        self.英雄组.draw(self.屏幕)
        self.英雄.子弹.update()
        self.英雄.子弹.draw(self.屏幕)

    @staticmethod
    def __游戏结束():
        print("游戏结束")
        pygame.quit()
        exit()
if __name__ == '__main__':
    #创建游戏对象
    游戏 = 飞机游戏()

    #启动游戏
    游戏.开始游戏()