try:
    #不能确定正确执行的代码
    数字 = int(input("输入一个整数: "))
except:
    #错误的处理代码
    print("请输入正确的整数")

print("*" * 50)