列表 = [i for i in range(1,45,3)]
print(列表)

列表1 = [j for j in range(45) if j % 3 == 1]
print(列表1)

#相当于两个for循环嵌套.
列表2 = [(a,b) for a in range(1,3) for b in range(3)]
print(列表2)

#字典推导式
字典 = {q : q**2 for q in range(1,5)}
print(字典)