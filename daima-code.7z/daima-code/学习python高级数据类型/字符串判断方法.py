#判断空白字符
空字符 = " \t\r\n"
print(空字符.isspace())

#判断字符串中是否只包含数字
#数字字符 = "1.2"
#数字字符 = "①"
#数字字符 = "\u00b2"
数字字符 = "壹"
print(数字字符.isdecimal())
print(数字字符.isnumeric())
print(数字字符.isdigit())
print(数字字符)