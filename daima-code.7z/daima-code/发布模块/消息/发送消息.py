def 发送(文本):
    print("正在发送 %s"% 文本)