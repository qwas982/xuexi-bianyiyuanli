class 顺序栈(object):
    """栈"""
    #顺序栈
    def __init__(self):
        self.__list = []

    def 推(self,品目):
        """推进/推入一个新的元素品目到栈顶"""
        self.__list.append(品目)

    def 弹(self):
        """弹出一个栈顶元素"""
        return self.__list.pop()

    def 窥(self):
        """窥视栈顶元素并返回元素"""
        if self.__list:
            return self.__list[-1]
        else:
            return None

    def 是否空(self):
        """判断栈是否为空"""
        return self.__list == []

    def 尺寸(self):
        """返回栈的尺寸大小,即元素个数"""
        return len(self.__list)

    @staticmethod
    def 显示菜单():
        print("请选择功能: \n"
              "1,推入/推进 数据到 栈 里\n"
              "2,从 栈 里 弹出数据\n"
              "3,查看栈顶元素\n"
              "4,判断 栈 当前是否为空\n"
              "5,查看 栈 的大小/长度\n"
              "6,退出栈的操作")

    def 运行(self):
        while 1:
            self.显示菜单()
            序号 = input("输入你想执行的操作: ")
            if 序号 == "1":
                框 = input("输入放进栈的数据: ")
                self.推(框)
                print("\033[0;36m推栈成功! 当前栈有 %s 个元素,"
                      "当前栈的状态: %s \033[0m" \
                      %(self.尺寸(),self.__list))
            elif 序号 == "2":
                try:
                    self.弹()
                    print("\033[0;36m弹出成功! 当前栈有 %s 个元素,"
                        "当前栈的状态: %s \033[0m" \
                        % (self.尺寸(), self.__list))
                except Exception as e:
                    print("\033[0;36m 栈已空,无数据可弹出 \033[0m %s"
                          % e)
            elif 序号 == "3":
                print("\033[0;36m %s \033[0m"% self.窥())
            elif 序号 == "4":
                print("\033[0;36m %s \033[0m"% self.是否空())
            elif 序号 == "5":
                print("\033[0;36m当前栈有 %s 个元素,当前栈的状态: %s \033[0m" \
                      % (self.尺寸(), self.__list))
            elif 序号 == "6":
                break



if __name__ == "__main__":
    栈 = 顺序栈()
    栈.运行()

