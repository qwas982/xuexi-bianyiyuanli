from 学生 import *

#print("\033[0;36m 字串 \033[0m")

class 管理系统(object):
    def __init__(self):
        self.学生列表 = []

    def 运行(self):
        self.加载学生()
        while True:
            self.显示菜单()
            菜单序号 = int(input('请输入你需要的功能序号: '))
            if 菜单序号 == 1:
                self.添加学生()
            elif 菜单序号 == 2:
                self.删除学生()
            elif 菜单序号 == 3:
                self.修改学生()
            elif 菜单序号 == 4:
                self.查询学生()
            elif 菜单序号 == 5:
                self.显示学生()
            elif 菜单序号 == 6:
                self.保存学生()
            elif 菜单序号 == 7:
                break

    @staticmethod
    def 显示菜单():
        print("请选择如下功能: \n"
              "1,添加学员\n"
              "2,删除学员\n"
              "3,修改学员信息\n"
              "4,查询学员\n"
              "5,显示所有学员\n"
              "6,保存学员\n"
              "7,退出系统\n")

    def 添加学生(self):
        姓名 = input("请输入你的姓名: ")
        性别 = input("请输入你的性别: ")
        电话 = input("请输入你的电话: ")
        学员 = 学生(姓名,性别,电话)
        self.学生列表.append(学员)
        print(self.学生列表,"\n",学员)

    def 删除学生(self):
        要删除的 = input("请输入你想删除的学员姓名: ")
        for i in self.学生列表:
            if i.姓名 == 要删除的:
                self.学生列表.remove(i)
                break
        else:
            print("\033[0;36m 查无此人 \033[0m")

        print(self.学生列表)

    def 修改学生(self):
        要修改的 = input("请输入要修改的学员姓名: ")
        for i in self.学生列表:
            if i.姓名 == 要修改的:
                i.姓名 = input("学员的姓名想修改为: ")
                i.性别 = input("学员的性别想修改为: ")
                i.电话 = input("学员的电话想修改为: ")
                print("\033[0;36m 学员信息修改成功! \033[0m \n"
                      "新姓名: %s 新性别: %s 新电话: %s " \
                      % (i.姓名,i.性别,i.电话))
                break
        else:
            print("\033[0;37m 查无此人 \033[0m")

    def 查询学生(self):
        要查询的 = input("请输入要查询的学员姓名: ")
        for i in self.学生列表:
            if i.姓名 == 要查询的:
                print("姓名: %s 性别: %s 电话: %s " \
                    % (i.姓名, i.性别, i.电话))
                break
        else:
            print("\033[0;37m 查无此人 \033[0m")

    def 显示学生(self):
        print("姓名\t性别\t电话\t")
        for i in self.学生列表:
            print("姓名: %s 性别: %s 电话: %s " \
                  % (i.姓名, i.性别, i.电话))

    def 保存学生(self):
        文件 = open("学生.数据","w",encoding="UTF-8")

        新列表 = [i.__dict__ for i in self.学生列表]
        print(新列表)
        文件.write(str(新列表))

        文件.close()

    def 加载学生(self):
        try:
            文件 = open("学生.数据","r",encoding="UTF-8")
        except:
            文件 = open("学生.数据", "w", encoding="UTF-8")
        else:
            数据 = 文件.read()
            新列表 = eval(数据)
            self.学生列表 = [学生(i["姓名"],i["性别"],i["电话"])
                         for i in 新列表]
        finally:
            文件.close()
            