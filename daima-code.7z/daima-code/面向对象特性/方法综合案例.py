class 游戏(object):
    #历史最高分
    最高分 = 0
    def __init__(self,玩家姓名):
        self.玩家姓名 = 玩家姓名

    @staticmethod
    def 秀帮助():
        print("帮助信息: 让僵尸进入大门")

    @classmethod
    def 秀最高分(cls):
        print("历史记录 %d "% cls.最高分)

    def 开始游戏(self):
        print("%s 开始游戏啦..."% self.玩家姓名)

#查看游戏的帮助信息
游戏.秀帮助()

#查看历史最高分
游戏.秀最高分()

#创建游戏对象
游戏 = 游戏("小明")
游戏.开始游戏()

