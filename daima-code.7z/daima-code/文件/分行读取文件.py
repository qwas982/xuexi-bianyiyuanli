文件 = open("读我","r",encoding="UTF-8")

while 1:
    文本 = 文件.readline()
    #判断是否读取到内容
    if not 文本:
        break
        
    print(文本)

文件.close()