class 猫:
    def 吃(self,):
        print("小猫吃东西")

    def 喝(self):
        print("小猫喝东西")

#创建 猫对象
汤姆猫 = 猫()
汤姆猫.吃()
汤姆猫.喝()
print(汤姆猫)
地址 = id(汤姆猫)
print("%x"% 地址)