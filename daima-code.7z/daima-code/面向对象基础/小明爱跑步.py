class 人:
    def __init__(self,新名字,新体重):
        #self.属性 = 形参
        self.名字 = 新名字
        self.体重 = 新体重
    def __str__(self):
        return "我是 %s,体重是 %0.2f公斤" % (self.名字,self.体重)

    def 跑步(self):
        print("%s 爱跑步,跑步锻炼"% self.名字)
        self.体重 = self.体重 - 0.5
        print("%s 体重减少了0.5公斤 %0.2f公斤"% (self.名字,self.体重))

    def 吃(self):
        print("%s 在吃东西"% self.名字)
        self.体重 += 0.2
        print("%s 体重增加了0.2公斤 %0.2f公斤" % (self.名字,self.体重))

小明 = 人("小明",75.0)

小明.跑步()
小明.吃()
print(小明)

#小美爱跑步
小美 = 人("小美",65)
小美.吃()
小美.跑步()
print(小美)
