#提示用户输入一个整数
try:
    数字 = int(input("请输入一个整数: "))
    #使用 8 除以输入的整数并输出
    结果 = 8 / 数字
    print(结果)

# except ZeroDivisionError:
#     print("除以0错误")
except ValueError:
    print("不是有效十进制数字")

#捕获未知错误
except Exception as 结果:
    print("未知错误 %s "% 结果)

else:
    print("尝试成功")
finally:
    print("无论是否出现错误,都会执行")
print("%s-分割线-%s"% ("-" *30,"-" *20))


