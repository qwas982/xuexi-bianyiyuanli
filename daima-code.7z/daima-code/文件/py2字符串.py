# *-* coding:utf8 *-*

#引号前面的u告诉解释器这是一个utf8编码字符串
你好字串 = u"你好世界"
print(你好字串)

for 字 in 你好字串:
    print(字)