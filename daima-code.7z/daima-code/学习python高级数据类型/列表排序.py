列 = ["北京","上海","广州","深圳"]
列二 = ["4","8","3","0","2"]

#升序
# 列.sort()
# 列二.sort()

#降序
# 列.sort(reverse=True)
# 列二.sort(reverse=True)

#逆序
列.reverse()
列二.reverse()

print(列)
print(列二)