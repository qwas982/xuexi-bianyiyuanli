# 兰姆达 = lambda a:a
# print(兰姆达("你好世界"))

# 兰姆达 = lambda a,b:a + b
# print(兰姆达(3,5))

# 兰姆达 = lambda *元组参:元组参
# print(兰姆达(3,5,6))

# 兰姆达 = lambda **字典参:字典参
# print(兰姆达(名字="小明",年龄=18,性别="女"))

兰姆达 = lambda a,b:a if a > b else b
print(兰姆达(3,6))