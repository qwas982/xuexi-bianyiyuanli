def 演示1():
    return int(input("输入整数: "))

def 演示2():
    return 演示1()

#利用异常的传递性,在主程序捕获异常
try:

    print(演示2())
except Exception as 结果:
    print("未知错误 %s" % 结果)
