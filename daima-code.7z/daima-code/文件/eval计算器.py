输入字串 =  input("请输入算术题: ")

print(eval(输入字串))
