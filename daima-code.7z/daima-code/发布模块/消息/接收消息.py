def 接收():
    return "这是来自 10086 的短信"