#打开
文件读 = open("读我","r",encoding="UTF-8")
文件写 = open("读我-副本","w",encoding="UTF-8")

#读写
# 文本 = 文件读.read()
# 文件写.write(文本)
#假如逐行读取
while 1:
    #每次只读一行内容
    文本 = 文件读.readline()
    #判断是否读取到内容
    if not 文本:
        break

    文件写.write(文本)

#关闭
文件读.close()
文件写.close()