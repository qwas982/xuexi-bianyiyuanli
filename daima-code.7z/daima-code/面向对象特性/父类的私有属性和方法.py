class a:
    def __init__(self):
        self.数字1 = 100
        self.__私属性 = 2

    def __私方法(self):
        print("私有方法 %d %d"% (self.数字1,self.__私属性))

    def 公有方法(self):
        print("这是父类的公有方法")
    def 测试私方法(self):
        print("父类的公有方法  %d"% self.__私属性)
        self.__私方法()

class b(a):
    def 演示(self):
        #验证访问父类的私有属性
        #print("验证访问父类的私有属性%d"% self.__私属性)
        #验证结果,在子类方法中不能,

        #验证调用父类的私有方法
        #self.__私方法()

        #访问父类的公有属性
        print("子类方法 %d"% self.数字1)
        #调用父类公有方法
        self.公有方法()
        self.测试私方法()

        pass



#创建一个对象
b = b()
print(b)

b.演示()
# print(b.数字1)
# b.公有方法()
#在外界不能直接访问/调用 私属性 私方法
#print(b.__私属性)
#b.__私方法()
