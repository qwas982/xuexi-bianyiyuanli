class 枪:
    def __init__(self,型号):
        #1枪的型号
        self.型号 = 型号

        #2子弹的数量
        self.子弹数量 = 0


    def 加子弹(self,数量):
        self.子弹数量 += 数量

    def 射击(self):
        #1判断子弹数量
        if self.子弹数量 <= 0:
            print("%s 没子弹了"% self.型号)
            return
        #2发射子弹,每次 -1
        self.子弹数量 -= 2

        #3提示发射信息
        print("%s 发射中... %d"% (self.型号,self.子弹数量))


class 士兵:
    def __init__(self,姓名):
        #姓名
        self.姓名 = 姓名

        #枪 - 因为新兵没有枪
        self.枪 = None

    def 开火(self):
        #1判断士兵是否有枪
        if self.枪 is None:
            print("%s 还没有枪"% self.姓名)
            return

        #2喊口号
        print("冲啊...%s"% self.姓名)

        #3给枪装填子弹
        self.枪.加子弹(50)

        #4让枪发射子弹
        self.枪.射击()

#1创建枪对象
ak47 = 枪("ak47")

#2创建许三多
许三多 = 士兵("许三多")

许三多.枪 = ak47
许三多.开火()
print(许三多.枪)