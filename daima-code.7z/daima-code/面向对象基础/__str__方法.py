class 猫:
    def __init__(self,新名字):
        self.名字 = 新名字
        print("%s 来了"% self.名字)

    def __del__(self):
        print("%s 我走了"% self.名字)

    def __str__(self):
        #必须返回一个字符串
        return "我是小猫[%s]"% self.名字

#家猫 是一个全局变量
家猫 = 猫("喵咪")
print(家猫)