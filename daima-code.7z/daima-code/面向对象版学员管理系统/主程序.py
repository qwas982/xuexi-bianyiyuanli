from 管理系统 import *

if __name__ == '__main__':
    学生管理 = 管理系统()
    学生管理.运行()