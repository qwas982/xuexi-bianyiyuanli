class 学生(object):
    def __init__(self, 姓名, 性别, 电话):
        self.姓名 = 姓名
        self.性别 = 性别
        self.电话 = 电话

    def __str__(self):
        return "姓名: %s 性别: %s 电话: %s " \
               % (self.姓名, self.性别, self.电话)
