#全局变量
标题 = "模块2"

#函数
def 说你好():
    print("我是 %s"% 标题)

#类
class 猫(object):
    pass
