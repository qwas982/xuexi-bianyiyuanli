import random

# 范围 = random.randint(0,10)
# print(范围)
print(random.__file__)