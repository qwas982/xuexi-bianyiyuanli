class 啊(object):
    a = 0

    def __init__(self):
        self.b = 1

啊啊 = 啊()
print(啊.__dict__)
print(啊啊.__dict__)