import pygame
from 飞机精灵 import *

#游戏的初始化
pygame.init()

#创建游戏窗口 需求: 480 * 700
屏幕 = pygame.display.set_mode((480,700))

#绘制背景图像
#加载图,绘制图,更新图,
背景 = pygame.image.load("./图片/背景.png")
屏幕.blit(背景,(0,0))
#pygame.display.update()

#绘制英雄的飞机
英雄 = pygame.image.load("./图片/我1.png")
屏幕.blit(英雄,(200,500))

#可以在所有绘制工作完成后,统一调用update方法
pygame.display.update()

#创建时钟对象
时钟 = pygame.time.Clock()


# i = 0
#1定义rect记录飞机的初始位置
英雄rect = pygame.Rect(150,300,102,126)

#创建敌机的精灵
敌人 = 游戏精灵("./图片/diren1.png",)
敌人1 = 游戏精灵("./图片/diren1.png",)
#创建敌机的精灵组
敌人组 = pygame.sprite.Group(敌人,敌人1)









#游戏循环-游戏循环的开始意味着游戏正式开始
while 1:
    #可指定循环体内代码执行的频率
    时钟.tick(240)
    # #捕获事件
    # 事件列表 = pygame.event.get()
    # if len(事件列表) > 0:
    #     print(事件列表)
    #监听事件,
    for 事件 in pygame.event.get():
        #判断事件类型是否是退出事件
        if 事件.type == pygame.QUIT:
            print("游戏退出...")
            #quit 卸载所有模块
            pygame.quit()
            #exit() 内置函数直接终止当前执行的程序
            exit()

    #2修改飞机的位置
    英雄rect.y -= 1
    #判断飞机的位置
    if 英雄rect.y <= -126:
        英雄rect.y = 700

    #3调用blit方法绘制图像
    屏幕.blit(背景,(0,0))
    屏幕.blit(英雄,英雄rect)
    #让精灵组调用两个方法 update draw
    敌人组.update()
    敌人组.draw(屏幕)


    #4调用update方法更新显示
    pygame.display.update()

    # print(i)
    # i += 1
    # pass

pygame.quit()
