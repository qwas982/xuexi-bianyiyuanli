class 播放器(object):
    #记录第一个被创建对象的引用
    探知 = None
    #记录是否执行过初始化动作
    初始化旗 = False

    def __new__(cls, *args, **kwargs):
        #判断类属性是否是空对象
        if cls.探知 is None:
            # 调用父类的方法,为第一个对象分配空间
            cls.探知 = super().__new__(cls)

        #返回类属性保存的对象引用
        return cls.探知

    def __init__(self):
        #判断是否执行过初始化动作
        if 播放器.初始化旗:
            return

        #若没有,再执行
        print("初始化播放器")

        #修改类属性的标记
        播放器.初始化旗 = True





#创建多个对象
播放器1 = 播放器()
print(播放器1)

播放器2 = 播放器()
print(播放器2)