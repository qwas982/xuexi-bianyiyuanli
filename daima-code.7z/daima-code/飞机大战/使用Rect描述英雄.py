import pygame

英雄rect = pygame.Rect(100,500,120,125)
print("英雄的原点 %d %d"% (英雄rect.x,英雄rect.y))
print("英雄的尺寸 %d %d"% (英雄rect.width,英雄rect.height))
print("%d %d"% 英雄rect.size)