class 甲:
    def 测试(self):
        print("甲的---测试 方法")
    def 演示(self):
        print("甲的---演示 方法")

class 乙:
    def 演示(self):
        print("演示 方法")
    def 测试(self):
        print("测试 方法")

class 丙(乙,甲):
    '''多继承可以让子类对象,同时具有多个父类的方法和属性'''
    pass

#创建子类对象
西 = 丙()

西.测试()
西.演示()
print(丙.__mro__)