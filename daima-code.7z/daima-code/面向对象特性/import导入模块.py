# import 测试模块1
# import 测试模块2
import 测试模块1 as DogModule
import 测试模块2 as CatModule


# 测试模块1.说你好()
# 测试模块2.说你好()
DogModule.说你好()
CatModule.说你好()


狗 = DogModule.狗()
print(狗)

猫 = CatModule.猫()
print(猫)