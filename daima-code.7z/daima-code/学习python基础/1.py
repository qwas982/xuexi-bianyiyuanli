#wo = "shi nie"
#print(wo)


#用中文汉字汉语编程来实现编的练习
#模仿和抄写他人的蟒蛇爬虫代码
#因为一开始没有用纯粹的中文汉字汉语来命名,所以
#中英文混杂,导致字符逻辑不通
# 下次改正,尝试全中文汉字汉语作为字符表示.
#当然,关键字和内置函数方法改不了就暂时依旧
#19.6.6


import urllib

###
#爬虫v0.1 利用urllib 和 字符串内建函数
###

def 获取超文本(网页):
    #获取网页内容
    一页 = urllib.urlopen(网页)
    超文本 = 一页.读()
    return 超文本

def content(html):
    #内容分割的标签
    str = '<article class ="article-content">'
    content = html.partition(str)[2]
    str1 = '<div class="article-social">'
    content = content.partition(str1)[0]
    return content   #得到网页的内容


def 标题(content,beg = 0):
    #思路是利用str.index()和序列的切片
    try:
        标题列表 = []
        while True:
            数1 = content.index(']',beg)
            数2 = content.index('</p>',数1)
            title_list.append(content[数1:数2])
            beg = 数2

    except ValueError:
        return 标题列表

def img(content,beg = 0):
    #思路是利用str.index()和序列号的切片
    try:
        img_list = []            
        while True:
            src1 = content.index('http',beg)
            src2 = content.index('/></p>',src1)
            img_list.append(content[src1:src2])
            beg = src2

    except ValueError:
        return img_list

def date_out(date):
    #这里写成一个方法好处是,在写入文本的时候就在这里写
    fo = open("/home/qq/date.txt","a+")
    for i,e in enumerate(date):
    fo.write("\n".join(date));
        print '第%d个,title: %s' % (i,e)
    fo.close()


def 很多图片(数据,beg = 0):
    #用于匹配多图片中的url
    try:
        很多图片字串 = ''
        while True:
            源1 = 数据.索引('http',beg)
            源2 = 数据.索引('/><br /> <img src =',源1)
            很多图片字串 += 数据[源1:源2]+'|'
            beg = 源2
    except ValueError:
        return 很多图片字串

def 数据出(标题,图片):
    #写入文本
    with open("/家/扣扣/数据.txt","a+") as fo:
        fo.写('\n')
        for 尺寸 in 范围(0,长(标题)):
            if 长(图片[尺寸]) > 70:             
                图片[尺寸] = 很多图片(图片[尺寸])  
            fo.写(标题)[尺寸]+'S'+图片[尺寸]+'\n'


content = content(获取超文本(""))
标题 = 标题(content)
图片 = 获取图片(content)
数据出(标题,图片)
#实现了爬的单个页面的标题和图片的网页地址并存入文本

