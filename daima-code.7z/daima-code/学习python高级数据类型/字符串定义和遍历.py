字串1 = "你好 蟒蛇"
字串2 = "我喜欢吃'大西瓜'"

print(字串2)
print(字串1[3])

#for 字串 in 字串2:
 #   print(字串)

print(len(字串2))
print(字串2.count(字串2))