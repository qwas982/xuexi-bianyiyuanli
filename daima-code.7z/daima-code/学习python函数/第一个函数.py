名字 = "小明"

def 问好():
    """这是问好的函数"""
    print("你好1")
    print("你好2")
    print("你好3")

print(名字)
问好()
print(名字)