#全局变量
标题 = "模块1"

#函数
def 说你好():
    print("我是 %s"% 标题)

#类
class 狗(object):
    pass
