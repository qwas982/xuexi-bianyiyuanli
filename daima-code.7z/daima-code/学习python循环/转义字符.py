# \t 制表, 对齐
print("1\t 2\t 3\t" )
print("10\t 20\t 30\t" )

# \r 回车, \n 换行
print("你好\n派生")
print("双\'引\"号")

print("演示\r回车")
print("演示\\反斜杠")