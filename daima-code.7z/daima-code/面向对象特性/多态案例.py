class 狗(object):
    def __init__(self,名字):
        self.名字 = 名字

    def 游戏(self):
        print("%s 蹦蹦跳跳地玩耍"% self.名字)

class 哮天犬(狗):
    def 游戏(self):
        print("%s 飞到天上去了"% self.名字)

class 人(object):
    def __init__(self,姓名):
        self.姓名 = 姓名

    def 与狗玩游戏(self,狗):
        print("%s 和 %s 快乐地玩耍"% (self.姓名,狗.名字))

        #让狗玩耍
        狗.游戏()

#创狗对象
#儍佝 = 狗("儍佝")
儍佝 = 哮天犬("飞天儍佝")

#创人对象
小明 = 人("小明")

#让人与狗玩
小明.与狗玩游戏(儍佝)

