你好字 = "你好世界"

#判断是否以指定字符串开始
print(你好字.startswith("你好"))

#判断是否以指定字符串结束
print(你好字.endswith("世界"))

#查找指定字符串
print(你好字.find("世"))

#替换字符串
#replace方法会修改字符串,给出一个新的,但不会修改原有的.
print(你好字.replace("世界","蟒蛇"))
print(你好字)