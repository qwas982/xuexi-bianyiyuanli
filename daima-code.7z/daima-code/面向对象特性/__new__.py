class 音乐播放器(object):
    def __new__(cls, *args, **kwargs):
        #创对象时,new方法会被自动调用
        print("创建对象,分配空间")
        #为对象分配空间
        探知 = super().__new__(cls)
        #返回对象的引用
        return 探知
    def __init__(self):
        print("播放器初始化")

#创播放器对象
播放者 = 音乐播放器()
print(播放者)